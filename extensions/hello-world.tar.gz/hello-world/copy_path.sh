#!/bin/bash
# File explorer context menu: copy file path to clipboard
FILE="$1"
if command -v xclip &>/dev/null; then
    echo -n "$FILE" | xclip -selection clipboard
elif command -v xsel &>/dev/null; then
    echo -n "$FILE" | xsel --clipboard
elif command -v wl-copy &>/dev/null; then
    echo -n "$FILE" | wl-copy
fi
