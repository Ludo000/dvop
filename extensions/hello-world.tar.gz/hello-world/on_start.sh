#!/bin/bash
# Hook: on_app_start
echo "[hello-world] Extension loaded!" >&2
