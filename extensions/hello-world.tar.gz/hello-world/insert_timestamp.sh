#!/bin/bash
# Editor context menu: insert current timestamp
date '+%Y-%m-%d %H:%M:%S'
