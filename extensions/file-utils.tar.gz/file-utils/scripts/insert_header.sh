#!/bin/bash
# Command: insert a file header comment based on file extension
FILE="$1"
EXT="${FILE##*.}"

case "$EXT" in
    rs)
        echo "// ──────────────────────────────────────────"
        echo "// File: $(basename "$FILE")"
        echo "// Created: $(date '+%Y-%m-%d')"
        echo "// ──────────────────────────────────────────"
        echo ""
        ;;
    py)
        echo "# ──────────────────────────────────────────"
        echo "# File: $(basename "$FILE")"
        echo "# Created: $(date '+%Y-%m-%d')"
        echo "# ──────────────────────────────────────────"
        echo ""
        ;;
    js|ts)
        echo "/**"
        echo " * File: $(basename "$FILE")"
        echo " * Created: $(date '+%Y-%m-%d')"
        echo " */"
        echo ""
        ;;
    sh|bash)
        echo "#!/bin/bash"
        echo "# ──────────────────────────────────────────"
        echo "# File: $(basename "$FILE")"
        echo "# Created: $(date '+%Y-%m-%d')"
        echo "# ──────────────────────────────────────────"
        echo ""
        ;;
    *)
        echo "// File: $(basename "$FILE")"
        echo "// Created: $(date '+%Y-%m-%d')"
        echo ""
        ;;
esac
