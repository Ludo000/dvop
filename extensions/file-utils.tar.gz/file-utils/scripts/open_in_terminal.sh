#!/bin/bash
# File explorer context menu: open a terminal in the file's directory
FILE="$1"
DIR=$(dirname "$FILE")
if command -v xdg-terminal-exec &>/dev/null; then
    nohup xdg-terminal-exec --working-directory="$DIR" &>/dev/null &
elif command -v gnome-terminal &>/dev/null; then
    nohup gnome-terminal --working-directory="$DIR" &>/dev/null &
elif command -v xterm &>/dev/null; then
    nohup xterm -e "cd '$DIR' && bash" &>/dev/null &
fi
