#!/bin/bash
# Transform: add line numbers to stdin
nl -ba -w3 -s'  '
