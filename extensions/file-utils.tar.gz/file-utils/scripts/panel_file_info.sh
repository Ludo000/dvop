#!/bin/bash
# Sidebar panel: display file metadata and stats
FILE="$2"
ACTION="$1"

if [ ! -f "$FILE" ]; then
    echo "No file open"
    exit 0
fi

FILENAME=$(basename "$FILE")
DIRPATH=$(dirname "$FILE")
EXT="${FILENAME##*.}"
SIZE=$(stat --format=%s "$FILE" 2>/dev/null || stat -f%z "$FILE" 2>/dev/null || echo "?")
MODIFIED=$(stat --format='%y' "$FILE" 2>/dev/null | cut -d. -f1 || stat -f'%Sm' "$FILE" 2>/dev/null || echo "?")
LINES=$(wc -l < "$FILE" 2>/dev/null || echo 0)
WORDS=$(wc -w < "$FILE" 2>/dev/null || echo 0)
CHARS=$(wc -c < "$FILE" 2>/dev/null || echo 0)
PERMS=$(stat --format='%A' "$FILE" 2>/dev/null || stat -f'%Sp' "$FILE" 2>/dev/null || echo "?")

# Format file size
if [ "$SIZE" -lt 1024 ] 2>/dev/null; then
    HSIZE="${SIZE} B"
elif [ "$SIZE" -lt 1048576 ] 2>/dev/null; then
    HSIZE="$(echo "scale=1; $SIZE / 1024" | bc) KB"
elif [ "$SIZE" -lt 1073741824 ] 2>/dev/null; then
    HSIZE="$(echo "scale=1; $SIZE / 1048576" | bc) MB"
else
    HSIZE="${SIZE} B"
fi

echo "── File Info ──"
echo ""
echo "Name: $FILENAME"
echo "Type: $EXT"
echo "Dir:  $DIRPATH"
echo ""
echo "── Stats ──"
echo ""
echo "Size:     $HSIZE ($SIZE bytes)"
echo "Lines:    $LINES"
echo "Words:    $WORDS"
echo "Chars:    $CHARS"
echo "Modified: $MODIFIED"
echo "Perms:    $PERMS"

# Git info if available
if command -v git &>/dev/null && git -C "$DIRPATH" rev-parse --git-dir &>/dev/null 2>&1; then
    BRANCH=$(git -C "$DIRPATH" branch --show-current 2>/dev/null)
    STATUS=$(git -C "$DIRPATH" status --porcelain -- "$FILE" 2>/dev/null | head -c2)
    echo ""
    echo "── Git ──"
    echo ""
    echo "Branch: $BRANCH"
    case "$STATUS" in
        "M "| " M") echo "Status: Modified" ;;
        "A ") echo "Status: Added" ;;
        "??") echo "Status: Untracked" ;;
        "") echo "Status: Clean" ;;
        *) echo "Status: $STATUS" ;;
    esac
fi
