#!/bin/bash
# Hook: on_file_close - log the event
echo "[file-utils] Closed: $1" >&2
