#!/bin/bash
# Transform: remove blank/empty lines from stdin
sed '/^[[:space:]]*$/d'
