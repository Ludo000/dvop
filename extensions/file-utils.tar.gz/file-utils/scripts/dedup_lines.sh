#!/bin/bash
# Transform: remove duplicate consecutive lines from stdin
uniq
