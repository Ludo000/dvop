#!/bin/bash
# Hook: on_file_save - log with timestamp
echo "[file-utils] Saved: $1 at $(date '+%H:%M:%S')" >&2
