#!/bin/bash
# Transform: reverse lines from stdin
tac
