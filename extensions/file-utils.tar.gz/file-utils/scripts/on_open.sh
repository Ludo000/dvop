#!/bin/bash
# Hook: on_file_open
echo "[file-utils] Opened: $1" >&2
