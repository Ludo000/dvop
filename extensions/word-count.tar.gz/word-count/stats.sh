#!/bin/bash
# Command: show text statistics for the current file
FILE="$1"
if [ -f "$FILE" ]; then
    WORDS=$(wc -w < "$FILE")
    LINES=$(wc -l < "$FILE")
    CHARS=$(wc -c < "$FILE")
    BYTES=$(stat --format=%s "$FILE" 2>/dev/null || stat -f%z "$FILE" 2>/dev/null)
    echo "Words: $WORDS | Lines: $LINES | Chars: $CHARS | Bytes: $BYTES"
fi
