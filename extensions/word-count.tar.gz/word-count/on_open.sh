#!/bin/bash
# Hook: on_file_open - log to stderr (visible in terminal)
echo "[word-count] Opened: $1" >&2
