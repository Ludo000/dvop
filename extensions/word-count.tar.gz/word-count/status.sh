#!/bin/bash
# Status bar: show word and line count for the current file
FILE="$1"
if [ -f "$FILE" ]; then
    WORDS=$(wc -w < "$FILE" 2>/dev/null || echo 0)
    LINES=$(wc -l < "$FILE" 2>/dev/null || echo 0)
    echo "W:${WORDS} L:${LINES}"
fi
