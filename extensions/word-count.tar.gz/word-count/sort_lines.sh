#!/bin/bash
# Transform: sort lines from stdin
sort
