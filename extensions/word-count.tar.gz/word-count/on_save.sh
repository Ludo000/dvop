#!/bin/bash
# Hook: on_file_save - log to stderr
echo "[word-count] Saved: $1" >&2
