#!/bin/bash
# Transform: convert stdin to lowercase
tr '[:upper:]' '[:lower:]'
