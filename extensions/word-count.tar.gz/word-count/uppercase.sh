#!/bin/bash
# Transform: convert stdin to UPPERCASE
tr '[:lower:]' '[:upper:]'
