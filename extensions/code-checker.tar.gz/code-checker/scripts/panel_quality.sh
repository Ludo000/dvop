#!/bin/bash
# Sidebar panel: code quality overview for current file
FILE="$2"
ACTION="$1"

if [ ! -f "$FILE" ]; then
    echo "No file open"
    exit 0
fi

FILENAME=$(basename "$FILE")
LINES=$(wc -l < "$FILE" 2>/dev/null || echo 0)
TRAILING=$(grep -cE '[[:space:]]$' "$FILE" 2>/dev/null || echo 0)
LONG=$(awk 'length > 120' "$FILE" 2>/dev/null | wc -l || echo 0)
TODOS=$(grep -ciE '(TODO|FIXME|HACK|XXX)(\(|:| )' "$FILE" 2>/dev/null || echo 0)
BLANK=$(grep -c '^$' "$FILE" 2>/dev/null || echo 0)

echo "── Code Quality ──"
echo ""
echo "File: $FILENAME"
echo "Lines: $LINES (blank: $BLANK)"
echo ""
echo "── Issues ──"
echo ""
echo "Trailing whitespace: $TRAILING"
echo "Lines > 120 chars:   $LONG"
echo "TODO/FIXME markers:  $TODOS"
echo ""
TOTAL=$((TRAILING + LONG + TODOS))
if [ "$TOTAL" -eq 0 ]; then
    echo "✓ Clean — no issues found"
else
    echo "⚠ $TOTAL issue(s) found"
fi
