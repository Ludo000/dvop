#!/bin/bash
# Python-specific linter: missing docstrings, bare except, print statements
FILE="$1"
[ ! -f "$FILE" ] && echo "[]" && exit 0

diagnostics="["
first=true

lineno=0
while IFS= read -r line || [ -n "$line" ]; do
    lineno=$((lineno + 1))

    # Bare except
    if echo "$line" | grep -qE '^\s*except\s*:'; then
        [ "$first" = true ] && first=false || diagnostics="$diagnostics,"
        diagnostics="$diagnostics{\"severity\":\"warning\",\"message\":\"Bare 'except:' — catch a specific exception\",\"line\":$lineno,\"column\":1,\"rule\":\"no-bare-except\"}"
    fi

    # print() left in code (common debug leftover)
    if echo "$line" | grep -qE '^\s*print\s*\('; then
        [ "$first" = true ] && first=false || diagnostics="$diagnostics,"
        diagnostics="$diagnostics{\"severity\":\"info\",\"message\":\"print() statement found — consider using logging\",\"line\":$lineno,\"column\":1,\"rule\":\"no-print\"}"
    fi

    # Mutable default argument
    if echo "$line" | grep -qE 'def\s+\w+\(.*=\s*(\[\]|\{\})'; then
        [ "$first" = true ] && first=false || diagnostics="$diagnostics,"
        diagnostics="$diagnostics{\"severity\":\"warning\",\"message\":\"Mutable default argument — use None instead\",\"line\":$lineno,\"column\":1,\"rule\":\"no-mutable-default\"}"
    fi

done < "$FILE"

diagnostics="$diagnostics]"
echo "$diagnostics"
