#!/bin/bash
# Command/keybinding: remove trailing whitespace from selection (via stdin)
# When used as keybinding: $1=file_path $2=selection
# Output replaces selection
sed 's/[[:space:]]*$//'
