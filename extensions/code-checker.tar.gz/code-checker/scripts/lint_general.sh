#!/bin/bash
# General code linter: trailing whitespace, long lines, TODO/FIXME markers
FILE="$1"
[ ! -f "$FILE" ] && echo "[]" && exit 0

diagnostics="["
first=true

lineno=0
while IFS= read -r line || [ -n "$line" ]; do
    lineno=$((lineno + 1))

    # Trailing whitespace
    if [[ "$line" =~ [[:space:]]$ ]] && [ -n "$line" ]; then
        [ "$first" = true ] && first=false || diagnostics="$diagnostics,"
        diagnostics="$diagnostics{\"severity\":\"warning\",\"message\":\"Trailing whitespace\",\"line\":$lineno,\"column\":1,\"rule\":\"no-trailing-whitespace\"}"
    fi

    # Lines longer than 120 characters
    len=${#line}
    if [ "$len" -gt 120 ]; then
        [ "$first" = true ] && first=false || diagnostics="$diagnostics,"
        diagnostics="$diagnostics{\"severity\":\"info\",\"message\":\"Line exceeds 120 characters ($len)\",\"line\":$lineno,\"column\":121,\"rule\":\"max-line-length\"}"
    fi

    # TODO / FIXME markers
    if echo "$line" | grep -qiE '(TODO|FIXME|HACK|XXX)(\(|:| )'; then
        [ "$first" = true ] && first=false || diagnostics="$diagnostics,"
        diagnostics="$diagnostics{\"severity\":\"info\",\"message\":\"Found TODO/FIXME marker\",\"line\":$lineno,\"column\":1,\"rule\":\"no-todo\"}"
    fi

done < "$FILE"

diagnostics="$diagnostics]"
echo "$diagnostics"
